# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(bisect-regression src/bisect-regression.cpp)
set_property(TARGET bisect-regression PROPERTY CXX_STANDARD 11)
target_link_libraries(bisect-regression lionss pthread)

add_executable(qemu-riscv64 src/qemu-riscv64.cpp)
set_property(TARGET qemu-riscv64 PROPERTY CXX_STANDARD 11)
target_link_libraries(qemu-riscv64 lionss pthread)

add_executable(package-snap src/package-snap.cpp)
set_property(TARGET package-snap PROPERTY CXX_STANDARD 11)
target_link_libraries(package-snap lionss pthread)

add_executable(illumos-build src/illumos-build.cpp)
set_property(TARGET illumos-build PROPERTY CXX_STANDARD 11)
target_link_libraries(illumos-build lionss pthread)

add_executable(gcc-latest src/gcc-latest.cpp)
set_property(TARGET gcc-latest PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-latest lionss pthread)

add_executable(find-package-check src/find-package-check.cpp)
set_property(TARGET find-package-check PROPERTY CXX_STANDARD 11)
target_link_libraries(find-package-check lionss pthread)

add_executable(regression-suite src/regression-suite.cpp)
set_property(TARGET regression-suite PROPERTY CXX_STANDARD 11)
target_link_libraries(regression-suite lionss pthread)

add_executable(package-pkg src/package-pkg.cpp)
set_property(TARGET package-pkg PROPERTY CXX_STANDARD 11)
target_link_libraries(package-pkg lionss pthread)

add_executable(release-dry-run src/release-dry-run.cpp)
set_property(TARGET release-dry-run PROPERTY CXX_STANDARD 11)
target_link_libraries(release-dry-run lionss pthread)

add_executable(secrets-scan src/secrets-scan.cpp)
set_property(TARGET secrets-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(secrets-scan lionss pthread)

add_executable(canary-build src/canary-build.cpp)
set_property(TARGET canary-build PROPERTY CXX_STANDARD 11)
target_link_libraries(canary-build lionss pthread)

add_executable(fuzz-corpus src/fuzz-corpus.cpp)
set_property(TARGET fuzz-corpus PROPERTY CXX_STANDARD 11)
target_link_libraries(fuzz-corpus lionss pthread)

add_executable(version-bump src/version-bump.cpp)
set_property(TARGET version-bump PROPERTY CXX_STANDARD 11)
target_link_libraries(version-bump lionss pthread)

add_executable(latency-bench src/latency-bench.cpp)
set_property(TARGET latency-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(latency-bench lionss pthread)

add_executable(api-compat-check src/api-compat-check.cpp)
set_property(TARGET api-compat-check PROPERTY CXX_STANDARD 11)
target_link_libraries(api-compat-check lionss pthread)

add_executable(lsan src/lsan.cpp)
set_property(TARGET lsan PROPERTY CXX_STANDARD 11)
target_link_libraries(lsan lionss pthread)

add_executable(clang-17 src/clang-17.cpp)
set_property(TARGET clang-17 PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-17 lionss pthread)

add_executable(sonarcloud src/sonarcloud.cpp)
set_property(TARGET sonarcloud PROPERTY CXX_STANDARD 11)
target_link_libraries(sonarcloud lionss pthread)

add_executable(in-source-guard src/in-source-guard.cpp)
set_property(TARGET in-source-guard PROPERTY CXX_STANDARD 11)
target_link_libraries(in-source-guard lionss pthread)

add_executable(fixme-scan src/fixme-scan.cpp)
set_property(TARGET fixme-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(fixme-scan lionss pthread)

add_executable(static-binary src/static-binary.cpp)
set_property(TARGET static-binary PROPERTY CXX_STANDARD 11)
target_link_libraries(static-binary lionss pthread)

add_executable(strict-warnings src/strict-warnings.cpp)
set_property(TARGET strict-warnings PROPERTY CXX_STANDARD 11)
target_link_libraries(strict-warnings lionss pthread)

add_executable(build-no-exceptions src/build-no-exceptions.cpp)
set_property(TARGET build-no-exceptions PROPERTY CXX_STANDARD 11)
target_link_libraries(build-no-exceptions lionss pthread)

add_executable(weekly-build src/weekly-build.cpp)
set_property(TARGET weekly-build PROPERTY CXX_STANDARD 11)
target_link_libraries(weekly-build lionss pthread)

add_executable(build-release src/build-release.cpp)
set_property(TARGET build-release PROPERTY CXX_STANDARD 11)
target_link_libraries(build-release lionss pthread)

add_executable(toc-check src/toc-check.cpp)
set_property(TARGET toc-check PROPERTY CXX_STANDARD 11)
target_link_libraries(toc-check lionss pthread)

add_executable(package-dmg src/package-dmg.cpp)
set_property(TARGET package-dmg PROPERTY CXX_STANDARD 11)
target_link_libraries(package-dmg lionss pthread)

add_executable(memory-profile src/memory-profile.cpp)
set_property(TARGET memory-profile PROPERTY CXX_STANDARD 11)
target_link_libraries(memory-profile lionss pthread)

add_executable(maximal-versions src/maximal-versions.cpp)
set_property(TARGET maximal-versions PROPERTY CXX_STANDARD 11)
target_link_libraries(maximal-versions lionss pthread)

add_executable(endianness-check src/endianness-check.cpp)
set_property(TARGET endianness-check PROPERTY CXX_STANDARD 11)
target_link_libraries(endianness-check lionss pthread)

