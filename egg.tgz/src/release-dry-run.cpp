// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("release dry run"); }
int main(){
  announce();
  return lionss_run_workload("release-dry-run");
}
