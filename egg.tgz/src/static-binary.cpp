// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("static binary"); }
int main(){
  announce();
  return lionss_run_workload("static-binary");
}
